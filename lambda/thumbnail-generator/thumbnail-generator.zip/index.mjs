import { GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import sharp from "sharp";

const s3 = new S3Client({});

async function streamToBuffer(stream) {
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }

  return Buffer.concat(chunks);
}

function getThumbnailKey(rawKey) {
  const decodedKey = decodeURIComponent(rawKey.replace(/\+/g, " "));
  if (!decodedKey.startsWith("uploads/raw/")) {
    return null;
  }

  const filename = decodedKey.split("/").pop();
  if (!filename) {
    return null;
  }

  return {
    rawKey: decodedKey,
    thumbnailKey: `uploads/thumbnails/${filename}.webp`
  };
}

export const handler = async (event) => {
  const results = [];

  for (const record of event.Records ?? []) {
    const bucket = record.s3?.bucket?.name;
    const keyInfo = getThumbnailKey(record.s3?.object?.key ?? "");

    if (!bucket || !keyInfo) {
      results.push({ status: "skipped", reason: "unsupported-record" });
      continue;
    }

    try {
      const object = await s3.send(
        new GetObjectCommand({
          Bucket: bucket,
          Key: keyInfo.rawKey
        })
      );

      if (!object.Body) {
        throw new Error(`S3 object ${keyInfo.rawKey} did not include a body.`);
      }

      const sourceBuffer = await streamToBuffer(object.Body);
      const thumbnail = await sharp(sourceBuffer, { failOn: "none" })
        .rotate()
        .resize(150, 150, {
          fit: "cover",
          position: "attention",
          withoutEnlargement: true
        })
        .webp({ quality: 78, effort: 4 })
        .toBuffer();

      await s3.send(
        new PutObjectCommand({
          Bucket: bucket,
          Key: keyInfo.thumbnailKey,
          Body: thumbnail,
          ContentType: "image/webp",
          CacheControl: "public, max-age=31536000, immutable",
          Metadata: {
            source: keyInfo.rawKey
          }
        })
      );

      results.push({
        status: "created",
        sourceKey: keyInfo.rawKey,
        thumbnailKey: keyInfo.thumbnailKey
      });
    } catch (error) {
      console.error("Thumbnail generation failed", {
        bucket,
        key: keyInfo.rawKey,
        error
      });
      throw error;
    }
  }

  return { results };
};
